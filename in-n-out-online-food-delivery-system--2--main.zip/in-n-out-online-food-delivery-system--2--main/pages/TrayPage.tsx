
import React, { useState } from 'react';
import { useCart } from '../context/CartContext';
import { useOrders } from '../context/OrderContext';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { ButtonSpinner } from '../components/LoadingSpinner';

interface TrayPageProps {
  onExploreMenu: () => void;
  onNavToLogin: () => void;
  onOrderSuccess?: () => void;
}

export const TrayPage: React.FC<TrayPageProps> = ({ onExploreMenu, onNavToLogin, onOrderSuccess }) => {
  const { cart, removeFromCart, updateQuantity, cartTotal, clearCart } = useCart();
  const { placeOrder } = useOrders();
  const { currentUser } = useAuth();
  const { showToast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleCheckout = () => {
    if (!currentUser) {
      showToast("Identity verification required for checkout.", "warning");
      return onNavToLogin();
    }
    if (!cart.length) return;

    setIsProcessing(true);
    
    // Simulate logistics transmission
    setTimeout(() => {
      placeOrder(currentUser, cart, cartTotal);
      clearCart();
      setIsProcessing(false);
      showToast("Order Dispatched: Logistics team notified.", "success");
      if (onOrderSuccess) onOrderSuccess();
    }, 2000);
  };

  if (!cart.length) return (
    <div className="min-h-[80vh] flex flex-col items-center justify-center p-8 animate-fade-in text-center">
      <div className="w-72 h-72 bg-gray-50 dark:bg-zinc-900 rounded-[60px] flex items-center justify-center mb-12 border-4 border-dashed dark:border-zinc-800 shadow-inner group">
        <span className="text-9xl transform group-hover:scale-110 transition-transform">🥡</span>
      </div>
      <h2 className="text-4xl font-black text-gray-900 dark:text-white uppercase tracking-tighter mb-4 italic">Empty Manifest</h2>
      <button 
        onClick={onExploreMenu} 
        className="bg-ino-red text-white px-16 py-7 rounded-[32px] font-black uppercase tracking-[0.3em] text-[11px] shadow-2xl"
      >
        Replenish Inventory
      </button>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-6 py-20 animate-fade-in">
      <div className="flex flex-col lg:flex-row gap-16 items-start">
        <div className="flex-grow space-y-12 w-full">
          <div className="border-b dark:border-zinc-800 pb-12">
             <h1 className="text-6xl font-black text-gray-900 dark:text-white uppercase tracking-tighter italic leading-none">Review <span className="text-ino-red">Tray</span></h1>
          </div>

          <div className="space-y-6">
            {cart.map(item => (
              <div key={item.cartItemId} className="bg-white dark:bg-zinc-900 p-8 rounded-[48px] border dark:border-zinc-800 shadow-sm flex items-center gap-10">
                <div className="w-32 h-32 rounded-[32px] overflow-hidden flex-shrink-0 relative">
                  <img src={item.image} className="w-full h-full object-cover" alt={item.name} />
                </div>
                <div className="flex-grow">
                  <div className="flex justify-between items-start mb-6">
                    <div>
                      <h4 className="text-2xl font-black text-gray-900 dark:text-white uppercase italic">{item.name}</h4>
                      <span className="text-[9px] font-black uppercase text-ino-red bg-red-50 dark:bg-red-900/10 px-4 py-1.5 rounded-xl">{item.selectedSize}</span>
                    </div>
                    <span className="font-black text-3xl text-gray-900 dark:text-white">ETB {(item.selectedPrice * item.quantity).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center mt-6">
                    <div className="flex items-center gap-8 bg-gray-50 dark:bg-zinc-800 p-3.5 rounded-2xl">
                      <button onClick={() => updateQuantity(item.cartItemId, item.quantity - 1)} className="w-8 h-8 font-black text-gray-400 hover:text-ino-red text-xl">-</button>
                      <span className="text-sm font-black dark:text-white w-6 text-center">{item.quantity}</span>
                      <button onClick={() => updateQuantity(item.cartItemId, item.quantity + 1)} className="w-8 h-8 font-black text-gray-400 hover:text-emerald-500 text-xl">+</button>
                    </div>
                    <button onClick={() => removeFromCart(item.cartItemId)} className="text-[10px] font-black text-gray-300 hover:text-ino-red uppercase tracking-[0.4em]">Decommission</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:w-[480px] w-full shrink-0">
          <div className="bg-white dark:bg-zinc-900 p-12 rounded-[60px] border dark:border-zinc-800 shadow-2xl sticky top-32">
            <h3 className="text-2xl font-black text-gray-900 dark:text-white uppercase tracking-widest italic mb-12">Manifest Summary</h3>
            
            <div className="space-y-6 mb-12 border-t dark:border-zinc-800 pt-10">
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Base Value</span>
                <span className="font-black text-xl dark:text-white">ETB {cartTotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Logistic Fee</span>
                <span className="font-black text-xl text-emerald-500">ETB 2.99</span>
              </div>
              <div className="flex justify-between items-center pt-10 border-t dark:border-zinc-800">
                <span className="text-3xl font-black uppercase italic dark:text-white">Gross Total</span>
                <span className="text-5xl font-black text-ino-red italic">ETB {(cartTotal + 2.99).toFixed(2)}</span>
              </div>
            </div>

            <button 
              onClick={handleCheckout} 
              disabled={isProcessing}
              className={`w-full ${isProcessing ? 'bg-gray-100 dark:bg-zinc-800' : 'bg-ino-red'} text-white py-9 rounded-[32px] font-black uppercase text-[11px] tracking-[0.4em] shadow-2xl`}
            >
              {isProcessing ? <ButtonSpinner /> : 'Authorize Deployment'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
